# ARV Active Summary Table

- Source directory: `/home/jj/maifs/TEMP_1_zip_bundle/temp_1774932539118_EXPERIMENT_RESULTS/summaries`
- Merged from:
  - `ARV_ACTIVE_CPU_EXPERIMENT_SUMMARY_20260330.md`
  - `ARV_ACTIVE_CPU_PCI_EXPERIMENT_SUMMARY_20260330.md`
  - `ARV_ACTIVE_ALL_BACKENDS_EXPERIMENT_SUMMARY_20260330.md`

## Summary Document Index

| Summary file | Scope | Backends covered | Core result table | Main takeaway |
| --- | --- | --- | --- | --- |
| `ARV_ACTIVE_CPU_EXPERIMENT_SUMMARY_20260330.md` | CPU 단독 active discovery + latency | `CPU` | CPU discovery, per-image result, notable cases | 6장 전체에서 active case 24건이 발견됐고 평균 active E2E는 `215.058 ms`였다. |
| `ARV_ACTIVE_CPU_PCI_EXPERIMENT_SUMMARY_20260330.md` | CPU와 PCIe HAT 비교 | `CPU`, `PCIe HAT` | backend aggregate, discovery difference, latency comparison | `PCIe HAT`은 `54.961 ms`로 CPU보다 훨씬 빨랐고 active case는 8건만 남았다. |
| `ARV_ACTIVE_ALL_BACKENDS_EXPERIMENT_SUMMARY_20260330.md` | 전체 backend 비교 | `CPU`, `USB Coral`, `PCIe HAT` | backend aggregate, discovery difference, latency comparison | `USB Coral`과 `PCIe HAT`은 같은 2장 이미지에서만 active case를 찾았고, `PCIe HAT`이 가장 빨랐다. |

## Unified Backend Result Table

| Backend | Included summary docs | Discovery active cases | `keep_change` | `revert_to_base` | Avg active E2E (ms) | Avg active stage-2 (ms) | Keep-case avg E2E (ms) | Revert-case avg E2E (ms) | Fastest case | Slowest case |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| `CPU` | CPU / CPU+PCI / ALL | 24 | 15 | 9 | 215.058 | 8.865 | 212.488 | 219.342 | `cpu_aigenproxy_keep_change_0016` = 181.483 ms | `cpu_dsC_keep_change_0014` = 289.724 ms |
| `USB Coral` | ALL | 8 | 8 | 0 | 75.723 | 7.293 | 75.723 | — | `coral_opensdi_keep_change_0007` = 74.287 ms | `coral_aigenproxy_keep_change_0008` = 78.163 ms |
| `PCIe HAT` | CPU+PCI / ALL | 8 | 8 | 0 | 54.961 | 3.816 | 54.961 | — | `pcie-hat_base_keep_change_0005` = 52.471 ms | `pcie-hat_opensdi_keep_change_0003` = 57.064 ms |

## Per-Image Active Discovery Matrix

| Image | CPU | USB Coral | PCIe HAT |
| --- | --- | --- | --- |
| `opensdi__authentic__000142.jpg` | 4개 모델 모두 `keep_change` | active case 없음 | active case 없음 |
| `opensdi__authentic__000276.jpg` | 4개 모델 모두 `revert_to_base` | 4개 모델 모두 `keep_change` | 4개 모델 모두 `keep_change` |
| `opensdi__manipulated__000219.jpg` | `base=keep_change`, `dsC/opensdi/aigenproxy=revert_to_base` | 4개 모델 모두 `keep_change` | 4개 모델 모두 `keep_change` |
| `opensdi__manipulated__000223.jpg` | 4개 모델 모두 `keep_change` | active case 없음 | active case 없음 |
| `opensdi__manipulated__000228.jpg` | `base/dsC/aigenproxy=keep_change`, `opensdi=revert_to_base` | active case 없음 | active case 없음 |
| `opensdi__manipulated__000280.jpg` | `base/dsC/aigenproxy=keep_change`, `opensdi=revert_to_base` | active case 없음 | active case 없음 |

## Cross-Document Key Points

| Topic | Result |
| --- | --- |
| Fastest backend | `PCIe HAT`이 평균 active E2E `54.961 ms`로 가장 빨랐다. |
| Middle backend | `USB Coral`은 평균 active E2E `75.723 ms`로 CPU보다 빠르고 PCIe HAT보다는 느렸다. |
| Slowest backend | `CPU`는 평균 active E2E `215.058 ms`로 가장 느렸지만 active case는 가장 많이 발견했다. |
| Active case pattern | `USB Coral`과 `PCIe HAT`은 같은 2장 이미지에서만 active case를 찾았고 모두 `keep_change`였다. |
| Backend sensitivity | 같은 probe set에서도 backend별 1단계 점수 차이 때문에 active case 수와 `keep/revert` 분포가 달라졌다. |
| Stability | 세 summary 문서 공통으로 선택된 case들은 반복 측정 동안 `active_run_rate=1.0`으로 안정적으로 유지됐다. |
| USB device note | 전체 backend summary 기준, `USB Coral` 측정은 `device=usb` 확인 후 수행됐다. |

## Source Summary Files

| File | Path |
| --- | --- |
| CPU summary | `/home/jj/maifs/TEMP_1_zip_bundle/temp_1774932539118_EXPERIMENT_RESULTS/summaries/ARV_ACTIVE_CPU_EXPERIMENT_SUMMARY_20260330.md` |
| CPU + PCI summary | `/home/jj/maifs/TEMP_1_zip_bundle/temp_1774932539118_EXPERIMENT_RESULTS/summaries/ARV_ACTIVE_CPU_PCI_EXPERIMENT_SUMMARY_20260330.md` |
| All backends summary | `/home/jj/maifs/TEMP_1_zip_bundle/temp_1774932539118_EXPERIMENT_RESULTS/summaries/ARV_ACTIVE_ALL_BACKENDS_EXPERIMENT_SUMMARY_20260330.md` |
