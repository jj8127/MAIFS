# PAPER_DRAFT_ARV_v3 공유용 결과 디렉토리

기준 논문:
- [PAPER_DRAFT_ARV_v3.md](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/00_docs/PAPER_DRAFT_ARV_v3.md)

이 디렉토리는 현재 v3 초안에 실제로 들어간 실험 수치와 그 근거 파일을 한곳에 모아 둔 공유용 묶음이다.

## 디렉토리 구성

- [00_docs](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/00_docs)
  - 현재 v3 초안 본문
  - v3 결과 요약본
- [01_problem_and_main](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/01_problem_and_main)
  - 문제 분석, 메인 결과, 통계 검정의 핵심 근거
- [02_dataset_and_alpha](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/02_dataset_and_alpha)
  - 데이터셋별 결과, `alpha=1.0` vs `alpha=1.5` 비교 근거
- [03_repeat_backbone](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/03_repeat_backbone)
  - 10회 반복 strong-backbone 검증 근거
- [04_rpi_latency](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/04_rpi_latency)
  - Raspberry Pi 5 SPR-active 종단간 추론시간 근거
- [05_backbone_eval_inputs](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/05_backbone_eval_inputs)
  - 문제 분석과 기본 분류기 성능 해석에 사용된 strong backbone prediction 원본

## 표/문단별 출처

### 1. 3장 문제 분석

현재 v3의 3장 숫자는 아래 두 축으로 묶어 확인하면 된다.

- 문제 분석 요약:
  - [PAPER_DRAFT_ARV_v3_RESULTS_SUMMARY.md](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/00_docs/PAPER_DRAFT_ARV_v3_RESULTS_SUMMARY.md)
- strong MobileNetV2 원본 예측:
  - [mobilenetv2_dualstream_base_20260319_070725.jsonl](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/05_backbone_eval_inputs/mobilenetv2_dualstream_base_20260319_070725.jsonl)
  - [mobilenetv2_dualstream_dsC_20260319_070725.jsonl](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/05_backbone_eval_inputs/mobilenetv2_dualstream_dsC_20260319_070725.jsonl)
  - [mobilenetv2_dualstream_opensdi_20260319_070725.jsonl](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/05_backbone_eval_inputs/mobilenetv2_dualstream_opensdi_20260319_070725.jsonl)
  - [mobilenetv2_dualstream_aigenproxy_20260319_070725.jsonl](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/05_backbone_eval_inputs/mobilenetv2_dualstream_aigenproxy_20260319_070725.jsonl)

### 2. 6.1 메인 결과

표 2와 본문 메인 수치의 직접 근거:

- 메인 결과 JSON:
  - [comp_nots_richer_veto_20260325_084631.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/01_problem_and_main/comp_nots_richer_veto_20260325_084631.json)
- 통계 검정, bootstrap CI, McNemar:
  - [arv_paper_support_analyses_20260328_135801.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/01_problem_and_main/arv_paper_support_analyses_20260328_135801.json)

여기서 확인 가능한 핵심 값:
- 기본 분류기 단독 F1 `0.9581`
- SPR F1 `0.9652`
- 교정 `52`
- 역교정 `18`
- pooled macro-F1 `0.9562 -> 0.9643`
- 95% CI `[0.0045, 0.0117]`
- McNemar `b=18`, `c=52`, `p=5.8e-5`

### 3. 6.2 데이터셋별 결과

표 4의 `base`, `dsC`, `OpenSDI`, `aigenproxy` 값은 아래 파일에서 직접 확인된다.

- [comp_nots_richer_veto_20260325_084631.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/01_problem_and_main/comp_nots_richer_veto_20260325_084631.json)

표 4에서 읽는 주요 항목:
- 기본 분류기 단독 F1
- SPR F1
- 1단계 역교정 건수
- SPR 교정 건수
- SPR 역교정 건수
- 역교정 감소율
- 도움이 된 변경 비율

### 4. 6.3 반복 실험

표 5와 strong backbone 반복 검증 수치는 아래 파일이 직접 근거다.

- [arv_strong_backbone_repeats_20260328_124619.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/03_repeat_backbone/arv_strong_backbone_repeats_20260328_124619.json)

여기서 확인 가능한 핵심 값:
- MobileNetV2 strong 10회 반복:
  - 기본 분류기 단독 `0.9581`
  - SPR `0.9644`
  - 평균 역교정 `20.2`
  - 역교정 감소율 `49.5%`
- MobileCLIP-ft strong 10회 반복:
  - 기본 분류기 단독 `0.9455`
  - SPR `0.9498`
  - 평균 역교정 `10.0`
  - 역교정 감소율 `76.7%`
- strong backbone 2종 합산:
  - 1단계 평균 역교정 총합 `83`
  - SPR 평균 역교정 총합 `30.2`
  - 평균 감소율 `63.6%`
  - 평균 순이득 `44.0`

보조 참고:
- [mobileclip_s2_finetuned_summary_20260319_061834.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/03_repeat_backbone/mobileclip_s2_finetuned_summary_20260319_061834.json)

### 5. alpha 비교

`alpha=1.0`과 `alpha=1.5` 비교는 아래 파일들을 함께 보면 된다.

- 최종 richer veto 비교:
  - [comp_nots_richer_veto_alpha1p5_20260329_161903.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/02_dataset_and_alpha/comp_nots_richer_veto_alpha1p5_20260329_161903.json)
- scalar 단계:
  - [hema_icwmv_veto_loo_cd_alpha1p5_20260329_144920.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/02_dataset_and_alpha/hema_icwmv_veto_loo_cd_alpha1p5_20260329_144920.json)
- meta warmstart 단계:
  - [hema_icwmv_veto_meta_warmstart_alpha1p5_20260329_145021.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/02_dataset_and_alpha/hema_icwmv_veto_meta_warmstart_alpha1p5_20260329_145021.json)
- 실험 요약 문서:
  - [ARV_E2E_ALL_BACKENDS_EXPERIMENT_SUMMARY_20260329.md](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/02_dataset_and_alpha/ARV_E2E_ALL_BACKENDS_EXPERIMENT_SUMMARY_20260329.md)

현재 v3 본문에 반영된 핵심 값:
- `alpha=1.0` 최종 SPR F1 `0.9652`
- `alpha=1.5` 최종 SPR F1 `0.9637`

### 6. Raspberry Pi 5 결과

표 6과 7장 수치의 근거는 아래 파일들이다.

- CPU raw discovery:
  - [20260331_cpu_arv_active_discovery.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/04_rpi_latency/20260331_cpu_arv_active_discovery.json)
- CPU raw latency:
  - [20260331_cpu_arv_active_latency.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/04_rpi_latency/20260331_cpu_arv_active_latency.json)
- backend 통합 요약:
  - [ARV_ACTIVE_SUMMARY_TABLE_20260330.md](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/04_rpi_latency/ARV_ACTIVE_SUMMARY_TABLE_20260330.md)
  - [요약본.md](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/04_rpi_latency/%EC%9A%94%EC%95%BD%EB%B3%B8.md)

현재 v3 본문에 반영된 값:
- CPU:
  - 1단계 `206.193ms`
  - 2단계 `8.865ms`
  - 총 `215.058ms`
- USB Edge TPU:
  - 1단계 `68.430ms`
  - 2단계 `7.293ms`
  - 총 `75.723ms`
- PCIe HAT:
  - 1단계 `51.145ms`
  - 2단계 `3.816ms`
  - 총 `54.961ms`

## 빠른 확인 순서

동료가 빠르게 확인하려면 아래 순서가 가장 좋다.

1. [PAPER_DRAFT_ARV_v3_RESULTS_SUMMARY.md](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/00_docs/PAPER_DRAFT_ARV_v3_RESULTS_SUMMARY.md)
2. [comp_nots_richer_veto_20260325_084631.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/01_problem_and_main/comp_nots_richer_veto_20260325_084631.json)
3. [arv_paper_support_analyses_20260328_135801.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/01_problem_and_main/arv_paper_support_analyses_20260328_135801.json)
4. [arv_strong_backbone_repeats_20260328_124619.json](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/03_repeat_backbone/arv_strong_backbone_repeats_20260328_124619.json)
5. [ARV_ACTIVE_SUMMARY_TABLE_20260330.md](/data/jj812_files/MAIFS%20copy/docs/research/papers/PAPER_DRAFT_ARV_v3_SHARED_RESULTS/04_rpi_latency/ARV_ACTIVE_SUMMARY_TABLE_20260330.md)

## 주의

- 이 디렉토리는 현재 v3 초안에 실제로 반영된 수치 기준이다.
- 따라서 현재 초안에서 제거된 `DF40` 관련 값은 일부러 넣지 않았다.
- Raspberry Pi의 USB / PCIe는 현재 raw JSON보다 통합 요약 문서가 직접 출처 역할을 하고 있으므로, 두 summary markdown도 함께 포함했다.
